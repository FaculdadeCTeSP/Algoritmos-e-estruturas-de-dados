﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210427_Stack {
    class Stack {
        private Elemento topo;

        public Stack() { topo = null; }

        public void Push(int valor) { }

        public int Peek() { return 0; }

        public int Pop() { return 0; }

        public Elemento Reverse() { return null; }

        public override string ToString() {
            return null;
        }
    }
}
