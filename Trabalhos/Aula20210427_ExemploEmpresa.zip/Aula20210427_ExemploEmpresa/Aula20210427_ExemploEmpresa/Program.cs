﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210427_ExemploEmpresa {
    class Program {
        static void Main(string[] args) {
            //InteracaoUtilizador();

            ParteNova();

        }

        private static void ParteNova() {
            Empresa a = new Empresa();

            a.RegistarFuncionario(333, "Saraiva", 2, 3); // 0
            a.RegistarFuncionario(111, "Zeferino", 2, 1); // 1
            a.RegistarFuncionario(222, "Venâncio", 1, 1); // 2
            a.RegistarFuncionario(222, "Josefina", 1, 3); // 2


            Console.WriteLine(a.SelectionSort(a.Funcionarios)); // nome: Saraiva, Venâncio, Zeferino
            Console.WriteLine(a.BubbleSort(a.Funcionarios)); // dependentes: 1 (Zeferino), 1 (Venâncio), 3 (Saraiva), 3 (Josefina)
            // com ordenação interna
            Console.WriteLine(a.BubbleSort(a.Funcionarios)); // dependentes: 1 (Venâncio), 1 (Zeferino), 3 (Josefina), 3 (Saraiva)
        }   

        private static void InteracaoUtilizador() {
            Console.WriteLine("Pedidos dados");
        }
    }
}
