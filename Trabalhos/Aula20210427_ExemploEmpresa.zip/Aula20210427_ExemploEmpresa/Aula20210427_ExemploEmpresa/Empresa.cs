﻿using System;

namespace Aula20210427_ExemploEmpresa {
    internal class Empresa {
        private Funcionario[] tabela;
        public Empresa() {
        }

        public Funcionario[] Funcionarios { get => tabela; }

        internal void RegistarFuncionario(int numero, string nome, int nTitulares, int nDependentes) {
            throw new NotImplementedException();
        }

        internal bool SelectionSort(object p) {
            throw new NotImplementedException();
        }

        internal bool BubbleSort(Funcionario[] funcionarios) {
            throw new NotImplementedException();
        }
    }
}