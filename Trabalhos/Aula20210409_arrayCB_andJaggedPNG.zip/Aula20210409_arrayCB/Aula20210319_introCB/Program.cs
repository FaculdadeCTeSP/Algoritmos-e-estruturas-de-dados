﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210319_introCB {
    class Program {
        static void Main(string[] args) {
            Banco x = new Banco("Banco da turma TPSI");
            x.AbrirConta(111, "Zeferino", 120);
            x.AbrirConta(222, "Sebastiao", 200);
            x.AbrirConta(333, "Saraiva", 300);

            Console.WriteLine(x.ToString());

            Console.WriteLine("Depósito na conta 2, 20 euros");
            x.Deposito(2, 20);
            Console.WriteLine(x.ToString());


            Console.WriteLine("Levantamento da conta 3, de 30 euros");
            x.Levantamento(3, 30);
            Console.WriteLine(x.ToString());
            Console.WriteLine("== FIM ==");
        }
    }
}
