﻿using System;
using System.Text;

namespace Aula20210319_introCB {
    internal class Banco {
        private string nomeBanco;
        private ContaBancaria[] contas;
        private long ibanProximo = 1;

        public Banco() {
            // a primeira conta é a 1, e vai para o indice 0,
            // a segunda conta é a 2, e vai para o indice 1,
            // posso abrir até ao id 1000, e vai para o indice 999
            contas = new ContaBancaria[1000];
        }

        public Banco(string nome) : this() {
            this.nomeBanco = nome;
        }

        internal long AbrirConta(int nifPrimeiroTitular, string nomePrimeiroTitular, double quantia) {
            ContaBancaria nova = new ContaBancaria(nifPrimeiroTitular, nomePrimeiroTitular, quantia);
            nova.Iban = ibanProximo;
            contas[nova.Iban - 1] = nova;
            ibanProximo++;
            return nova.Iban;
        }

        internal void Levantamento(int v1, int v2) {
            throw new NotImplementedException();
        }

        internal void Deposito(long iban, double quantia) {
            // versão iterativa (pode não ser necessária...)
            for (int i = 0; i < ibanProximo - 1; i++) {
                if (contas[i].Iban == iban) {
                    contas[i].Deposito(quantia);
                    break;
                }
            }
        }

        public override string ToString() {
            StringBuilder res = new StringBuilder();
            res.AppendLine(string.Format("Listagem do banco {0}", this.nomeBanco));
            for (int i = 0; i < ibanProximo-1; i++) {
                res.AppendLine(string.Format("IBAN: {0}, primeiro Titular {1,20}, saldo = {2}",
                    contas[i].Iban, contas[i].PrimeiroTitular.Nome, contas[i].Saldo));
            }
            return res.ToString();
        }
    }
}