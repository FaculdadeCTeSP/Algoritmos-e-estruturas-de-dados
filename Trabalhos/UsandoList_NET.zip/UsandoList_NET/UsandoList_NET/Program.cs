﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsandoList_NET {
    class Program {
        static void Main(string[] args) {
            TabelaAlunos t = new TabelaAlunos();

            t.Registo(12, "Doze");
            t.Registo(13, "Treze");
            t.Registo(12, "Copia Doze");

            Console.WriteLine(t);

            Console.WriteLine("-----");
            Console.WriteLine(t.Encontrar(14));
        }
    }
}
