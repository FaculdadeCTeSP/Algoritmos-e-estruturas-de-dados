﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsandoList_NET {
    public class TabelaAlunos {
        private List<Aluno> bd;

        public TabelaAlunos() {
            bd = new List<Aluno>();
        }

        public void Registo(int numeroAluno, string nomeAluno) {
            Aluno novo = new Aluno {
                Numero = numeroAluno,
                Nome = nomeAluno
            };
            if (!bd.Contains(novo))
                bd.Add(novo);
        }

        public Aluno Encontrar(int numeroAluno) {
            Aluno resultado = bd.Find(a => a.Numero == numeroAluno);
            return resultado;
        }

        public override string ToString() {
            StringBuilder res = new StringBuilder();
            for (int i = 0; i < bd.Count; i++) {
                res.AppendLine(bd[i].ToString());
            }
            return res.ToString();
        }
    }
}
