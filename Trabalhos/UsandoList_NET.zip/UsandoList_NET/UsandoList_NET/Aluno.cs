﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsandoList_NET {
    public class Aluno {
        private int numero;
        private string nome;

        public int Numero { get => numero; set => numero = value; }
        public string Nome { get => nome; set => nome = value; }

        public Aluno() { }

        public override string ToString() {
            return string.Format("{0,10},{1}", Numero, Nome);
        }

        public override bool Equals(object obj) {
            if (obj != null && obj is Aluno) {
                return ((Aluno)obj).Numero == this.Numero;
            } else return false;
        }
    }
}
