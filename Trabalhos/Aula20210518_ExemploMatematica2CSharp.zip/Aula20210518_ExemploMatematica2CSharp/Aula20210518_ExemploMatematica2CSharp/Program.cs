﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210518_ExemploMatematica2CSharp {
    class Program {
        
        static void Main(string[] args) {
            int res =  MinhasFormulas.f(0, 5);

            Console.WriteLine("Resultado = {0}", res);
            Console.WriteLine("verificacao = {0}", 3 + 8 + 15 + 24 + 35);
        }
    }
}
