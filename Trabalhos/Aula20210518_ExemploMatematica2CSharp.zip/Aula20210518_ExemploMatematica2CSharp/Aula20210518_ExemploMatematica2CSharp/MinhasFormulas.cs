﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210518_ExemploMatematica2CSharp {
    class MinhasFormulas {
        //  f(x, n) = 3(1 + x) + 4(2 + x) + 5(3 + x) + ... (n+2)(n + x)
        // f(0, 5) = 3(1)+4(2)+5(3)+6(4)+7(5) = 3+8+15+24+35=85
        internal static int f(int x, int n) {
            int res = 0;
            for(int i = 1; i <= n; i++) {
                res += (i + 2) * (i + x);
            }
            return res;
        }
    }
}
