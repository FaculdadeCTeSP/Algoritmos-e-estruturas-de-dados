﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210423_factorialRecursivo {
    static class NossaMat {
        public static int Fatorial(int n) {
            if (n < 1)
                throw new Exception("Fatorial apenas de n >= 1");
            //if (n == 1) {
            //    return 1;
            //} else {
            //    return n * Fatorial(n - 1);
            //}
            return n == 1 ? 1 : n * Fatorial(n - 1);
        }
    }
}
