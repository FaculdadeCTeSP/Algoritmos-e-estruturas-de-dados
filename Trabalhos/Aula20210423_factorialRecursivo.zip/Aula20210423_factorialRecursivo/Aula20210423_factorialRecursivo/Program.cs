﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210423_factorialRecursivo {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine(NossaMat.Fatorial(5)); // 5 = 120
            Console.WriteLine(NossaMat.Fatorial(4)); // 4 = 24
            Console.WriteLine(NossaMat.Fatorial(3)); // 3 = 6
            Console.WriteLine(NossaMat.Fatorial(2)); // 2 = 2
            Console.WriteLine(NossaMat.Fatorial(1)); // 1 = 1
        }
    }
}

/*
 * 4! = 4 * 3! = 4 * 6 = 24
 * 3! = 3 * 2! = 3 * 2 = 6
 * 2! = 2 * 1! = 2 * 1 = 2
 * 1! = 1
 */
