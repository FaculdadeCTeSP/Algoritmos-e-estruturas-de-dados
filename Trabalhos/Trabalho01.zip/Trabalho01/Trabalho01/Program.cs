﻿using System;

namespace Trabalho01
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Rascunho
            /*bool OK = false;Funcionario vTemp = new Funcionario();
           while (OK == false)
           {
               Console.Write("Nome -> ");//256
               vTemp.Nome = Console.ReadLine();
               Console.Clear();
               if(vTemp.Nome != "")
               {
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }
           }
           OK = false;
           while (OK == false)
           {
               Console.Write("Nif -> ");//Regex
               string v = Console.ReadLine();
               Console.Clear();
               if (v != "")
               {
                   vTemp.NIF = Convert.ToInt32(v);
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }

           }
           OK = false;
           while (OK == false)
           {
               Console.Write("Idade -> ");//Filto
               string v = Console.ReadLine();
               Console.Clear();
               if (v != "")
               {
                   vTemp.Idade = Convert.ToInt32(v); 
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }
           }
           OK = false;
           while (OK == false)
           {
               Console.Write("Salario Base -> ");//Regex
               string v = Console.ReadLine();
               Console.Clear();
               if (v != "")
               {
                   vTemp.SalarioBase = Convert.ToDouble(v); ;
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }
           }
           OK = false;
           while (OK == false)
           {
               Console.Write("Situacao Matrimonial (C - Casado / S - Solteiro) -> ");//Filtro
               string vA = Console.ReadLine();
               if (vA == "C")
               {
                   vTemp.Defeciencias = true;
               }
               else if (vA == "S")
               {
                   vTemp.Defeciencias = false;
               }
               Console.Clear();
               if (vA == "S" || vA == "C")
               {
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }
           }
           OK = false;
           while (OK == false)
           {
               Console.Write("Numero de Titulares -> ");//Regex (1-2)
               string v = Console.ReadLine();
               Console.Clear();
               if (v != "")
               {
                   vTemp.Titulares = Convert.ToInt32(v);
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }
           }
           OK = false;
           while (OK == false)
           {
               Console.Write("Numero de Dependentes -> ");//Regex
               string v = Console.ReadLine();
               Console.Clear();
               if (v != null)
               {
               vTemp.Dependentes = Convert.ToInt32(v);
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }
           }

           OK = false;
           while (OK == false)
           {
               Console.Write("Tem Deficiencias? (S/N) -> ");//Filtro
               string vA = Console.ReadLine();
               if (vA == "S")
               {
                   vTemp.Defeciencias = true;
               }
               else if (vA == "N")
               {
                   vTemp.Defeciencias = false;
               }
               Console.Clear();
               if (vA == "S" || vA == "N")
               {
                   OK = true;
               }
               else
               {
                   Console.WriteLine("Tem que preencher algo!");
               }
           }
           Console.WriteLine("     -    Informacao   -");
           Console.WriteLine("Nome: " + vTemp.Nome);
           Console.WriteLine("Nif: " + vTemp.NIF);
           Console.WriteLine("Idade: " + vTemp.Idade);
           Console.WriteLine("Salario Base: " + vTemp.SalarioBase + " Euros");
           if (vTemp.SituacaoMatrimonial == true)
           {
               Console.WriteLine("Situacao Matrimonial: Casado");
           }
           else
           {
               Console.WriteLine("Situacao Matrimonial: Solteiro");
           }
           Console.WriteLine("Numero de Titulares: " + vTemp.Titulares);
           Console.WriteLine("Numero de Dependentes: " + vTemp.Dependentes);
           if (vTemp.SituacaoMatrimonial == true)
           {
               Console.WriteLine("Defeciencias: Sim");
           }
           else
           {
               Console.WriteLine("Defeciencias: Nao");
           }
           Console.WriteLine();
           Console.WriteLine("     - Salario Liquido -");
           Console.WriteLine(vTemp.SalarioLiquido() + " Euros");*/
            #endregion
            Empresa Empresa = new Empresa();

            #region Inserir Funcionarios
            Empresa.RegistarFuncionario(2, "Rui Azevedo", 1, 2);
            Empresa.RegistarFuncionario(7, "Joaquim Costa", 1, 2);
            Empresa.RegistarFuncionario(5, "Luis Silva", 2, 0);
            Empresa.RegistarFuncionario(3, "Ricardo Lourenco", 1, 1);
            Empresa.RegistarFuncionario(1, "Goncalo Garrido", 2, 3);
            Empresa.RegistarFuncionario(6, "Maria Adelaide", 1, 1);
            Empresa.RegistarFuncionario(4, "Diogo Silva", 1, 0);
            #endregion

            Console.WriteLine("     - Ordenar Por Numero de Dependentes -");
            for (int i = 0; i < Empresa.Funcionarios.Length; i++)
            {
                Funcionario vTemp = Empresa.BubbleSort(Empresa.Funcionarios)[i];
                Console.Write("" + vTemp.NumeroDeFuncionario);
                Console.Write("," + vTemp.Nome);
                Console.Write("," + vTemp.Titulares);
                Console.Write("," + vTemp.Dependentes);
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("     - Ordenar Por Nome -");
            for (int i = 0; i < Empresa.Funcionarios.Length; i++)
            {
                Funcionario vTemp = Empresa.SelectionSort(Empresa.Funcionarios)[i];
                Console.Write("" + vTemp.NumeroDeFuncionario);
                Console.Write("," + vTemp.Nome);
                Console.Write("," + vTemp.Titulares);
                Console.Write("," + vTemp.Dependentes);
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("     - Ordenar Por Numero de Dependentes e Nome -");
            for (int i = 0; i < Empresa.Funcionarios.Length; i++)
            {
                Funcionario vTemp = Empresa.BubbleSortV2(Empresa.Funcionarios)[i];
                Console.Write("" + vTemp.NumeroDeFuncionario);
                Console.Write("," + vTemp.Nome);
                Console.Write("," + vTemp.Titulares);
                Console.Write("," + vTemp.Dependentes);
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("Total de Funcionarios: " + Empresa.Funcionarios.Length + "");
            Console.ReadKey();
        }
    }
}
