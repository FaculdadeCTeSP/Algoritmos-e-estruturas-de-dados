﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trabalho01
{
    public class Empresa
    {
        //Variaveis
        private Funcionario[] tabela ;
        private List<Funcionario> vTempTabela = new List<Funcionario>();
        //Funcoes
        public Funcionario[] Funcionarios { get => ConverterListaParaArray(); } //Tirar valores da Tabela
        public Empresa()
        {

        }
        private Funcionario[] ConverterListaParaArray()
        {
            return vTempTabela.ToArray();
        }
        internal void RegistarFuncionario(int numero, string nome, int nTitulares, int nDependentes)
        {
            Funcionario vFuncionario = new Funcionario();
            vFuncionario.NumeroDeFuncionario = numero;
            vFuncionario.Nome = nome;
            vFuncionario.Titulares = nTitulares;
            vFuncionario.Dependentes = nDependentes;
            vTempTabela.Add(vFuncionario);
        }

        internal Funcionario[] SelectionSort(Funcionario[] funcionarios)
        {
            Funcionario[] vOriginal = funcionarios;

            int pos_min;
            string temp = "";
            for (int i = 0; i < vOriginal.Length - 1; i++)
            {
                pos_min = i; 
                for (int j = i + 1; j < vOriginal.Length; j++)
                {
                    if (vOriginal[j].Nome.CompareTo(vOriginal[pos_min].Nome) < 0)
                    {
                        pos_min = j;
                    }
                }

                if (pos_min != i)
                {
                    temp = vOriginal[i].Nome;
                    vOriginal[i].Nome = vOriginal[pos_min].Nome;
                    vOriginal[pos_min].Nome = temp;
                }
            }

            return vOriginal;
        }

        internal Funcionario[] BubbleSort(Funcionario[] funcionarios)
        {
            Funcionario[] vOriginal = funcionarios;
            Funcionario vTemp = new Funcionario();

            for (int i = vOriginal.Length - 1; i >= 0; i--)
            {
                for (int j = 0; j < i; j++)
                {
                    if (vOriginal[j].Dependentes < vOriginal[j + 1].Dependentes)
                    {
                        vTemp = vOriginal[j];
                        vOriginal[j] = vOriginal[j + 1];
                        vOriginal[j + 1] = vTemp;

                    }
                }
            }

            return vOriginal;
        }
        internal Funcionario[] BubbleSortV2(Funcionario[] funcionarios)
        {
            Funcionario[] vOriginal = funcionarios;
            Funcionario vTemp = new Funcionario();

            for (int i = vOriginal.Length - 1; i >= 0; i--)
            {
                for (int j = 0; j < i; j++)
                {
                    if (vOriginal[j].Dependentes < vOriginal[j + 1].Dependentes)
                    {
                        vTemp = vOriginal[j];
                        vOriginal[j] = vOriginal[j + 1];
                        vOriginal[j + 1] = vTemp;
                    }
                    else if(vOriginal[j].Dependentes == vOriginal[j + 1].Dependentes)
                    {
                        vOriginal = SelectionSortSlim(vOriginal, j , j + 1);
                    }
                }
            }

            return vOriginal;
        }
        private Funcionario[] SelectionSortSlim(Funcionario[] funcionarios
            , int pIndexMin, int pIndexMax)
        {
            Funcionario[] vOriginal = funcionarios;

            int pos_min;
            string temp = "";
            for (int i = pIndexMin; i < pIndexMax; i++)
            {
                pos_min = i;
                for (int j = i + 1; j < pIndexMax; j++)
                {
                    if (vOriginal[j].Nome.CompareTo(vOriginal[pos_min].Nome) < 0)
                    {
                        pos_min = j;
                    }
                }

                if (pos_min != i)
                {
                    temp = vOriginal[i].Nome;
                    vOriginal[i].Nome = vOriginal[pos_min].Nome;
                    vOriginal[pos_min].Nome = temp;
                }
            }

            return vOriginal;
        }
    }
}
