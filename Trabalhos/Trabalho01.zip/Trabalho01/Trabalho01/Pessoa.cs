﻿namespace Trabalho01
{
    public class Pessoa
    {
        public string Nome { get; set; }
        public int NIF { get; set; }
        public int Idade { get; set; }
        public double SalarioBase { get; set; }
    }

    public class Funcionario : Pessoa
    {
        public int NumeroDeFuncionario { get; set; }
        public bool SituacaoMatrimonial { get; set; }
        public int Titulares { get; set; }
        public int Dependentes { get; set; }
        public bool Defeciencias { get; set; }
        public double SalarioLiquido()
        {
            if (SalarioBase >= 0 && SalarioBase < 659.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.0);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.0);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.0);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.0);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.0);

                    default:
                        return SalarioBase - (SalarioBase * 0.0);
                }
            }
            else if (SalarioBase >= 659.00 && SalarioBase < 686.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.001);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.000);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.000);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.000);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.000);

                    default:
                        return SalarioBase - (SalarioBase * 0.000);
                }
            }
            else if (SalarioBase >= 686.00 && SalarioBase < 718.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.042);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.013);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.009);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.004);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.000);

                    default:
                        return SalarioBase - (SalarioBase * 0.000);
                }
            }
            else if (SalarioBase >= 718.00 && SalarioBase < 739.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.073);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.044);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.026);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.007);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.000);

                    default:
                        return SalarioBase - (SalarioBase * 0.000);
                }
            }
            else if (SalarioBase >= 739.00 && SalarioBase < 814.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.082);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.053);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.035);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.026);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.007);

                    default:
                        return SalarioBase - (SalarioBase * 0.000);
                }
            }
            else if (SalarioBase >= 814.00 && SalarioBase < 922.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.104);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.076);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.067);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.039);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.032);

                    default:
                        return SalarioBase - (SalarioBase * 0.013);
                }
            }
            else if (SalarioBase >= 922.00 && SalarioBase < 1005.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.116);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.089);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.081);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.053);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.045);

                    default:
                        return SalarioBase - (SalarioBase * 0.032);
                }
            }
            else if (SalarioBase >= 1005.00 && SalarioBase < 1065.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.124);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.098);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.089);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.062);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.049);

                    default:
                        return SalarioBase - (SalarioBase * 0.040);
                }
            }
            else if (SalarioBase >= 1065.00 && SalarioBase < 1143.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.135);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.117);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.109);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.082);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.073);

                    default:
                        return SalarioBase - (SalarioBase * 0.055);
                }
            }
            else if (SalarioBase >= 1143.00 && SalarioBase < 1225.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.145);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.128);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.118);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.092);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.083);

                    default:
                        return SalarioBase - (SalarioBase * 0.065);
                }
            }
            else if (SalarioBase >= 1225.00 && SalarioBase < 1321.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.156);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.148);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.130);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.110);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.093);

                    default:
                        return SalarioBase - (SalarioBase * 0.084);
                }
            }
            else if (SalarioBase >= 1321.00 && SalarioBase < 1424.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.166);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.158);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.140);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.122);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.103);

                    default:
                        return SalarioBase - (SalarioBase * 0.095);
                }
            }
            else if (SalarioBase >= 1424.00 && SalarioBase < 1562.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.177);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.169);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.150);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.132);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.114);

                    default:
                        return SalarioBase - (SalarioBase * 0.105);
                }
            }
            else if (SalarioBase >= 1562.00 && SalarioBase < 1711.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.191);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.183);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.166);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.147);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.138);

                    default:
                        return SalarioBase - (SalarioBase * 0.120);
                }
            }
            else if (SalarioBase >= 1711.00 && SalarioBase < 1870.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.205);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.199);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.182);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.165);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.157);

                    default:
                        return SalarioBase - (SalarioBase * 0.139);
                }
            }
            else if (SalarioBase >= 1870.00 && SalarioBase < 1977.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.215);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.210);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.191);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.174);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.166);

                    default:
                        return SalarioBase - (SalarioBase * 0.149);
                }
            }
            else if (SalarioBase >= 1977.00 && SalarioBase < 2090.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.225);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.220);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.202);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.183);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.176);

                    default:
                        return SalarioBase - (SalarioBase * 0.168);
                }
            }
            else if (SalarioBase >= 2090.00 && SalarioBase < 2218.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.235);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.230);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.213);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.195);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.185);

                    default:
                        return SalarioBase - (SalarioBase * 0.179);
                }
            }
            else if (SalarioBase >= 2218.00 && SalarioBase < 2367.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.245);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.241);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.233);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.205);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.197);

                    default:
                        return SalarioBase - (SalarioBase * 0.188);
                }
            }
            else if (SalarioBase >= 2367.00 && SalarioBase < 2535.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.255);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.251);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.243);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.216);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.208);

                    default:
                        return SalarioBase - (SalarioBase * 0.200);
                }
            }
            else if (SalarioBase >= 2535.00 && SalarioBase < 2767.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.265);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.260);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.253);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.226);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.218);

                    default:
                        return SalarioBase - (SalarioBase * 0.210);
                }
            }
            else if (SalarioBase >= 2767.00 && SalarioBase < 3104.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.278);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.273);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.265);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.238);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.230);

                    default:
                        return SalarioBase - (SalarioBase * 0.222);
                }
            }
            else if (SalarioBase >= 3104.00 && SalarioBase < 3534.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.294);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.293);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.289);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.265);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.261);

                    default:
                        return SalarioBase - (SalarioBase * 0.257);
                }
            }
            else if (SalarioBase >= 3534.00 && SalarioBase < 4118.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.305);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.305);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.299);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.285);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.271);

                    default:
                        return SalarioBase - (SalarioBase * 0.267);
                }
            }
            else if (SalarioBase >= 4118.00 && SalarioBase < 4650.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.323);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.320);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.316);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.299);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.286);

                    default:
                        return SalarioBase - (SalarioBase * 0.282);
                }
            }
            else if (SalarioBase >= 4650.00 && SalarioBase < 5194.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.333);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.330);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.326);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.312);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.305);

                    default:
                        return SalarioBase - (SalarioBase * 0.292);
                }
            }
            else if (SalarioBase >= 5194.00 && SalarioBase < 5880.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.343);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.340);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.336);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.322);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.318);

                    default:
                        return SalarioBase - (SalarioBase * 0.301);
                }
            }
            else if (SalarioBase >= 5880.00 && SalarioBase < 6727.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.363);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.361);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.355);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.348);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.346);

                    default:
                        return SalarioBase - (SalarioBase * 0.344);
                }
            }
            else if (SalarioBase >= 6727.00 && SalarioBase < 7939.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.373);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.371);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.369);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.358);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.356);

                    default:
                        return SalarioBase - (SalarioBase * 0.354);
                }
            }
            else if (SalarioBase >= 7939.00 && SalarioBase < 9560.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.393);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.391);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.389);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.378);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.376);

                    default:
                        return SalarioBase - (SalarioBase * 0.374);
                }
            }
            else if (SalarioBase >= 9560.00 && SalarioBase < 11282.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.403);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.401);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.399);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.392);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.386);

                    default:
                        return SalarioBase - (SalarioBase * 0.384);
                }
            }
            else if (SalarioBase >= 11282.00 && SalarioBase < 18854.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.413);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.411);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.409);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.402);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.400);

                    default:
                        return SalarioBase - (SalarioBase * 0.394);
                }
            }
            else if (SalarioBase >= 18854.00 && SalarioBase < 20221.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.423);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.421);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.419);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.412);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.410);

                    default:
                        return SalarioBase - (SalarioBase * 0.404);
                }
            }
            else if (SalarioBase >= 20221.00 && SalarioBase < 22749.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.431);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.431);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.429);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.422);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.420);

                    default:
                        return SalarioBase - (SalarioBase * 0.416);
                }
            }
            else if (SalarioBase >= 22749.00 && SalarioBase < 25276.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.441);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.441);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.439);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.432);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.430);

                    default:
                        return SalarioBase - (SalarioBase * 0.428);
                }
            }
            else if (SalarioBase >= 25276.00)
            {
                switch (Dependentes)
                {
                    case 0:
                        return SalarioBase - (SalarioBase * 0.451);

                    case 1:
                        return SalarioBase - (SalarioBase * 0.451);

                    case 2:
                        return SalarioBase - (SalarioBase * 0.449);

                    case 3:
                        return SalarioBase - (SalarioBase * 0.442);

                    case 4:
                        return SalarioBase - (SalarioBase * 0.440);

                    default:
                        return SalarioBase - (SalarioBase * 0.438);
                }
            }

            return 0;
        }
    }
}