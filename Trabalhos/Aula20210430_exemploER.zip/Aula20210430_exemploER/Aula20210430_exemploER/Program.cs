﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210430_exemploER {
    class Program {
        static void Main(string[] args) {
            Sistema s = new Sistema();
            s.RegistarNovaPessoa(111, "Zeferino");
            s.RegistarNovaPessoa(222, "Saraiva");
            s.RegistarNovoVeiculo("aa-11-22");
            s.RegistarNovoVeiculo("bb-33-44");

            s.PessoaCompraVeiculo(111, "aa-11-22");
        }
    }
}
