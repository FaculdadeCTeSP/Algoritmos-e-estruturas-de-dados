﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210430_exemploER {
    public class Sistema {
        private Pessoa[] tabelaPessoas;
        private Veiculo[] tabelaVeiculos;
        private Aluguer[] tabelaAlugueres;

        public Sistema() {
            tabelaPessoas = new Pessoa[100];
            tabelaVeiculos = new Veiculo[100];
            tabelaAlugueres = new Aluguer[10000];
        }

        public Pessoa[] TabelaPessoas { get => tabelaPessoas; }
        public Veiculo[] TabelaVeiculos { get => tabelaVeiculos; }

        public bool PessoaCompraVeiculo(int nifPessoa, string matricula) {
            Veiculo v = PesquisaVeiculo(matricula);
            Pessoa p = PesquisaPessoa(nifPessoa);

            if (p != null && v != null) {
                v.dono = p;
                return true;
            } else return false;
        }

        private Pessoa PesquisaPessoa(int nifPessoa) {
            throw new NotImplementedException();
        }

        private Veiculo PesquisaVeiculo(string matricula) {
            throw new NotImplementedException();
        }

        public bool RegistarNovaPessoa(int nif, string nome) {
            // validar se o nif estava repetido

            return true;
        }

        public bool RegistarNovoVeiculo(string matricula) {
            // validar se a matricula não é repetida

            return true;
        }
    }
}
