﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210430_exemploER {
    public class Veiculo {
        private string matricula;
        public Pessoa dono;

        public Veiculo() { }
        public string Matricula { get => matricula; set => matricula = value; }
    }
}
