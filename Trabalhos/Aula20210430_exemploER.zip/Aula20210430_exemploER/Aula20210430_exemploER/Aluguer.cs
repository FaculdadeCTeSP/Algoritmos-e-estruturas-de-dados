﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210430_exemploER {
    public class Aluguer {
        private DateTime dataInicio;
        private DateTime dataFim;
        private Pessoa quemAluga;
        private Veiculo quemEAlugado;

        public Aluguer() { }

        public DateTime DataInicio { get => dataInicio; set => dataInicio = value; }
        public DateTime DataFim { get => dataFim; set => dataFim = value; }
    }
}
