﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210430_exemploER {
    public class Pessoa {
        private int nif;
        private string nome;

        public Pessoa() { }
        public int Nif { get => nif; set => nif = value; }
        public string Nome { get => nome; set => nome = value; }
    }
}
