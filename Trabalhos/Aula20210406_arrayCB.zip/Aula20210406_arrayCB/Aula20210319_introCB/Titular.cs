﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210319_introCB {
    public class Titular {
        private int idade;
        private string nome;

        public Titular() { }

        public int Idade {
            get => idade;
            set {
                if (value >= 16 && value <= 160) {
                    idade = value;
                } else {
                    // o ideal seria levantar uma excepção
                    idade = 18;
                }
            }
        }
        public string Nome { get => nome; set => nome = value; }

    }
}
