﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210319_introCB {
    public class ContaBancaria {
        private double saldo;
        private long iban;
        private Titular primeiroTitular;
        private Titular segundoTitular;

        public ContaBancaria() { }
        public ContaBancaria(double saldo) {
            if (saldo <= 100) {
                // ideal seria lançar uma excepção
                this.saldo = 100;
            } else
                this.saldo = saldo;
        }

        public ContaBancaria(string nomePrimeiroTitular, double x) : this(x) {
            primeiroTitular = new Titular {
                Nome = nomePrimeiroTitular
            };
        }

        public double Saldo { get => saldo; /*set => saldo = value;*/}
        public long Iban { get => iban; set => iban = value; }
        public Titular SegundoTitular { get => segundoTitular;  }
        public Titular PrimeiroTitular { get => primeiroTitular; }

        public void Deposito(double quantia) {
            if (quantia > 0) {
                //saldo = saldo + quantia;
                saldo += quantia;
            }
        }

        // quantiaPretendida = 50
        // saldo = 20
        // entregar = 
        public double Levantamento(double quantiaPretendida) {
            if (quantiaPretendida > 0) {
                if (quantiaPretendida <= saldo) {
                    saldo -= quantiaPretendida;
                    return quantiaPretendida;
                } else {
                    double aLevantar = saldo;
                    saldo = 0;
                    return aLevantar;
                }
            } else
                // o ideal seria levantar uma excepção
                return 0;
        }
    }
}
