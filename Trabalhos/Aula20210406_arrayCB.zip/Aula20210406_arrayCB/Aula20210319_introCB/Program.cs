﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210319_introCB {
    class Program {
        static void Main(string[] args) {
            Banco x = new Banco("Banco da turma TPSI");
            x.AbrirConta("Zeferino", 120);
            x.AbrirConta("Sebastiao", 200);
            x.AbrirConta("Saraiva", 300);

            Console.WriteLine(x.ToString());

            Console.WriteLine("== FIM ==");
        }
    }
}
