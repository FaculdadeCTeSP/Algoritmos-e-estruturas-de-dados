﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210521_hash {
    public class Veiculo {
        public enum Cores { Branco, Preto }
        private string matricula;
        private string marca;
        private Cores cor;
        private int cilindrada;

        public Veiculo() { }
        public string Matricula { get => matricula; set => matricula = value; }
        public string Marca { get => marca; set => marca = value; }
        public Cores Cor { get => cor; set => cor = value; }
        public int Cilindrada { get => cilindrada; set => cilindrada = Math.Abs(value); }

        public override string ToString() {
            return string.Format("{0,15}, {1}", Matricula, Marca);
        }
    }
}
